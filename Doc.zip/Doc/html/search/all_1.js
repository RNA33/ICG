var searchData=
[
  ['get_5fa',['get_a',['../class_i_c_g.html#a4ef92e7c0525708871bae289dc19f26d',1,'ICG']]],
  ['get_5fb',['get_b',['../class_i_c_g.html#a673e1c31c99aa13e8eb01d8865741af5',1,'ICG']]],
  ['get_5fp',['get_p',['../class_i_c_g.html#a2ce52412a36ef05c4e0b0f5756e2f4dd',1,'ICG']]]
];
